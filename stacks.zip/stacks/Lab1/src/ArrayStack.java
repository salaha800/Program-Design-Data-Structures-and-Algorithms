public class ArrayStack implements Stack{
    Character [] data;
    int top;

    public ArrayStack(int capacity) {
        this.data =  new Character[capacity];
        this.top = 0;


    }


    @Override
    public void push(Character element) throws IllegalStateException {
        if (this.top == this.data.length) {
            throw new IllegalStateException("stack is full");
        } else {
            data[this.top] = element;
            top++;

        }
    }

    @Override
    public Character pop() {
        if (!isEmpty()) {
            Character newdata= data [top-1];
            data [top-1] =null;
            top=top-1;
            return newdata;

        }
        else return null;

    }

    @Override
    public Character peek() {
        if (!isEmpty())
            return data [top-1];
        else
            return null;

    }

    @Override
    public boolean isEmpty() {
        if (top==0)
        return true;
        else return false;
    }

    @Override
    public int size() {

        return top;
    }
}

