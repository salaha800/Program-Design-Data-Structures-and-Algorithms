/**
 * The demo class that we will run for testing
 * @author Christine Zarges
 * @version 1.0, 10th October 2017
 */

import java.util.Scanner;

public class BracketDemo {

    //private BracketCheckerSolutionBook bracketChecker = new BracketCheckerSolutionBook();
    private BracketChecker bracketChecker = new StackBracketChecker(1000);

    /**
     * A default constructor. Creates a BracketChecker object.
     */
    public BracketDemo(){
    }

    /**
     * Runs the demonstration.
     */
    private void run(){
        Scanner scanner = new Scanner(System.in);

        /**
         * Reads the String that will be checked.
         */
        System.out.print("Enter text: ");
        String text = scanner.nextLine();

        /**
         * Execute the method selected previously.
         */
        boolean result = bracketChecker.check(text);;

        /**
         * Print the result.
         */
        if (result)
            System.out.println("Text is correct.");
        else
            System.out.println("Text contains errors.");
    }

    public static void main(String args[]) {
        BracketDemo demo = new BracketDemo();
        demo.run();
    }
}