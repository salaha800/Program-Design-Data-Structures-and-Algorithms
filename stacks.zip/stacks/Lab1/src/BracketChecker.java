/**
 * A basic interface to check matching brackets.
 * @author Christine Zarges
 * @version 1.0, 2nd October 2018
 */

public interface BracketChecker {
    /**
     * Checks matching brackets assuming that round, square and curly brackets are used.
     * @param text the text to be checked
     * @return true if brackets are matched correctly, otherwise return false
     */
    public boolean check(String text);
}