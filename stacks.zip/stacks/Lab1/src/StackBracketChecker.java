public class StackBracketChecker implements BracketChecker{
    private Stack unmatchedBrackets;
    public StackBracketChecker(int capacity){
        unmatchedBrackets=new ArrayStack (capacity);
    }
    public boolean check(String text) {
        for (int i=0;i<text.length(); i++){
            if (text.charAt(i)=='{')

            {
             unmatchedBrackets.push(text.charAt(i));
            }
            if (text.charAt(i)=='(')
            {
                unmatchedBrackets.push(text.charAt(i));

            }
            if (text.charAt(i)=='[')
            {
                unmatchedBrackets.push(text.charAt(i));
            }
            if (text.charAt(i)=='}')
            {
                if (unmatchedBrackets.isEmpty())
                    return false;
                if (unmatchedBrackets.peek()=='{'){
                    unmatchedBrackets.pop();

                }
                else
                    return false;
            }
            if (text.charAt(i)==')'){
                if (unmatchedBrackets.isEmpty())
                    return false;
                if (unmatchedBrackets.peek()=='('){
                    unmatchedBrackets.pop();

                }
                else
                    return false;

            }
            if (text.charAt(i)==']') {
                if (unmatchedBrackets.isEmpty())
                    return false;
                if (unmatchedBrackets.peek()=='['){
                    unmatchedBrackets.pop();

                }
                else
                    return false;

            }
        }
        if (unmatchedBrackets.isEmpty())
            return true;
        else
            return false;

    }




}


