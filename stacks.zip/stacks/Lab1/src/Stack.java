import java.util.EmptyStackException;

/**
 * A Stack interface.
 * @author Christine Zarges
 * @version 1.0, 2nd October 2018
 */
public interface Stack {
    /**
     * Pushes an element onto the top of this list.
     * @param element the element to be pushed onto the top of this list
     */
    public void push(Character element);

    /**
     * Removes the object at the top of this list and returns that object as the value of this function.
     * @return the object at the top of this list or null if the list is empty
     */
    public Character pop();

    /**
     * Looks at the object at the top of this list without removing it from the list.
     * @return the object at the top of this list or null if the list is empty
     */
    public Character peek();

    /**
     * Tests if this list is empty.
     * @return True if the list is empty, false otherwise
     */
    public boolean isEmpty();

    /**
     * Returns the number of elements in the list.
     * @return  the number of elements in the list
     */
    public int size();
}